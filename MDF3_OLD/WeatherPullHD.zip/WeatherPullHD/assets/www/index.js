function checkWeather() {
	var zipValue = document.getElementById('name').value;
	webapi.changeActivity(zipValue);
}

//comment