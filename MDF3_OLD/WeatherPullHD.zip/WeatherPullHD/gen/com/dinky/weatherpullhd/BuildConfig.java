/** Automatically generated file. DO NOT MODIFY */
package com.dinky.weatherpullhd;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}