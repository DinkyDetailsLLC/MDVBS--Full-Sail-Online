/** Automatically generated file. DO NOT MODIFY */
package com.dan.weatherpull;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}